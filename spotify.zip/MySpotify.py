import spotipy.client as spotify
import spotipy.util as util
import sys
import traceback

class MySpotify:
    def __init__(self):
        self.token = None
        
    def _Login(self):
        try:
            scope = 'user-library-read, playlist-read-private, playlist-read-collaborative, user-modify-playback-state, user-read-currently-playing, user-read-playback-state'

            username = 'YOUR_SPOTIFY_USERNAME_HERE'
            token = util.prompt_for_user_token(sername, scope, 'CLIENT_ID', 'CLIENT_SECRET', "http://localhost/", "config.ini")
            if token:
                self._token = token
                print ("Spotify Login erfolgreich!")
                return (True, "")
            else:
                print ("Spotify Login fehlgeschlagen!")
                return (False, "Login fehlgeschlagen")
        except:
            self._token = None
            print (traceback.format_exc())
            print ("Spotify - Login failed")
            
            return (False, "Ausnahmefehler!")

    def GetDevices(self):
        (loggedIn, errMsg) = self._Login ()
        if not loggedIn:
            return (False, errMsg)
        try:
            sp = spotify.Spotify (auth=self._token)
            res = sp.devices ()
            devs = {}
            if res and "devices" in res.keys():
                for dev in res["devices"]:
                    devs[dev["name"]] = dev["id"]
                    try:
                        devs[dev["name"].lower()] = dev["id"]
                    except:
                        pass
            return devs 
        except:
            print (traceback.format_exc())
            return (False, "Ausnahmefehler!")

    def GetDeviceId(self, devName):
        try:
            sp = spotify.Spotify (auth=self._token)
            res = sp.devices ()
            if res and "devices" in res.keys():
                print ("Found %d devices:" % len(res["devices"]))
                for dev in res["devices"]:
                    print ("    " + dev["name"])
                    if dev["name"].lower() == devName.lower():
                        return dev["id"]
            else:
                print ("Keine Abspielgeräte gefunden.")
        except:
            print (traceback.format_exc())
        return None

    def Pause(self, device):
        (loggedIn, errMsg) = self._Login ()
        if not loggedIn:
            return (False, errMsg)
    
        devId = self.GetDeviceId (device)
        if not devId:
            return (False, "Unbekanntes Abspielgerät")

        try:
            sp = spotify.Spotify (auth=self._token)
            res = sp.pause_playback (devId)
            return (True, res)
        except:
            print (traceback.format_exc())
            return (False, "Ausnahmefehler!")

    def Play(self, device):
        (loggedIn, errMsg) = self._Login ()
        if not loggedIn:
            return (False, errMsg)
    
        devId = self.GetDeviceId (device)
        if not devId:
            return (False, "Unbekanntes Abspielgerät")

        try:
            sp = spotify.Spotify (auth=self._token)
            res = sp.start_playback(devId)
            return (True, res)
        except:
            print (traceback.format_exc())
            return (False, "Ausnahmefehler!")

    def GetPlaylists (self):
        (loggedIn, errMsg) = self._Login ()
        if not loggedIn:
            return (False, errMsg)
    
        try:
            sp = spotify.Spotify (auth=self._token)
            res = sp.current_user_playlists ()
            playlists = {}
            for pl in res["items"]:
                playlists[str(pl["name"]).lower()] = pl["id"]
            return (playlists, None)
        except:
            print (traceback.format_exc())
            return (False, "Ausnahmefehler!")
        
    def PlayPlaylist (self, name, device):
        name = name.lower()
        (loggedIn, errMsg) = self._Login ()
        if not loggedIn:
            return (False, errMsg)
    
        try:
            (playlists, errorMsg) = self.GetPlaylists ()
            if type(playlists) is not dict:
                return (False, errorMsg)

            devId = self.GetDeviceId (device)
            if not devId:
                return (False, "Unbekanntes Abspielgerät")
        
            if name not in playlists.keys():
                return (False, "Unbekannte Playlist")

            sp = spotify.Spotify (auth=self._token)
            sp.start_playback (devId, "spotify:playlist:" + playlists[name])
            return self.GetPlaybackState ()
        except:
            print (traceback.format_exc())
            return (False, "Ausnahmefehler!")

    def IsPlaying (self, devName):
        (loggedIn, errMsg) = self._Login ()
        if not loggedIn:
            return (False, errMsg)

        try:
            sp = spotify.Spotify (auth=self._token)
            
            res = sp.devices ()
            devs = {}
            if res and "devices" in res.keys():
                for dev in res["devices"]:
                    if dev["name"].lower() == devName.lower():
                        if dev["is_active"]:
                            res = sp.current_playback("DE")
                            if res is not None:
                                return (True, res)
            return (True, {"is_playing":False})   
            
        except:
            print (traceback.format_exc())
            return (False, "Ausnahmefehler!")

    def GetPlaybackState (self):
        (loggedIn, errMsg) = self._Login ()
        if not loggedIn:
            return (False, errMsg)

        try:
            sp = spotify.Spotify (auth=self._token)            
            res = sp.current_playback("DE")
            if res is not None:
                return (True, res)
            return (False, "Aktueller Wiedergabezustand kann nicht abgefragt werden.")   
            
        except:
            print (traceback.format_exc())
            return (False, "Ausnahmefehler!")

    def PlayArtist (self, artist, device):
        (loggedIn, errMsg) = self._Login ()
        if not loggedIn:
            return (False, errMsg)
    
        devId = self.GetDeviceId (device)
        if not devId:
            return (False, "Unbekanntes Abspielgerät")
        
        try:
            sp = spotify.Spotify (auth=self._token)
            res = sp.search (artist, type="artist", market="DE")
            if res is not None and "artists" in res.keys():
                if len (res["artists"]["items"]) == 0:
                    return (False, "Keine passende Musik gefunden")
                
                firstMatchUri = res["artists"]["items"][0]["uri"]
                sp.start_playback (devId, firstMatchUri)
                return self.GetPlaybackState ()
            else:
                return (False, "Aktueller Wiedergabezustand kann nicht abgerufen werden.")
        except:
            print (traceback.format_exc())
            return (False, "Ausnahmefehler!")

    def SetShuffle (self, onOff):
        (loggedIn, errMsg) = self._Login ()
        if not loggedIn:
            return (False, errMsg)
    
        (ok, playbackstate) = self.GetPlaybackState()
        if ok and playbackstate["shuffle_state"] != onOff:
            try:
                 sp = spotify.Spotify (auth=self._token)
                 sp.shuffle (onOff, playbackstate["device"]["id"])
            except:
                print (traceback.format_exc())
                return (False, "Ausnahmefehler!")